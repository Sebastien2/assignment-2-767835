import os
import json

import pandas as pd
from flask import Flask, redirect, url_for, request, render_template
import pika
import http.client

app=Flask(__name__)



connection=pika.BlockingConnection(pika.ConnectionParameters('rabbitmq-service', 30015))
channel=connection.channel()



@app.route("/set_data_ingestion_function", methods=["POST"])
def set_data_ingestion_function():
    res={
            "status": "success",
            "motive": "",
            "request": "set_data_ingestion_function",
            "result": ""
        }
    customer=request.form['customer_identifier']
    func=request.form['function']
    
    filename=customer+"_function.py"
    with open("/files/"+filename, "w") as f:
        f.write(func)
        f.close()
        res["result"]="File created: "+filename
    return json.dumps(res)
    #USELESS to put in the database
    #we put this into the mongodb database
    try:
        connexion=http.client.HTTPConnection("coredms-service", 30002)
        data={
                "customer_identifier": customer,
                "function": func
            }
        headers={"Content-type": "application/json"}
        connexion.request("POST", "/set_ingest_message_function", json.dumps(data), headers)
        response=connexion.getresponse()
        connexion.close()
    except HttpError as err:
        res['status']='failure'
        res['motive']="HttpError: "+str(err)
        return json.dumps(res)
    except Exception as err:
        res['status']='failure'
        res['motive']="Exception: "+str(err)
        return json.dumps(res)
    res['result']=response.read().decode()['data']
    return json.dumps(res)



@app.route("/execute_ingestion", methods=["POST"])
def execute_ingestion():
    customer=request.form['customer_identifier']
    #TODO: get the file, put the function as callback for rabbitmq, and activate the reading of the whole queue















app.run(host='0.0.0.0', port=80, debug=True)
